import {createContext} from "react"

const Mycontext=createContext()

export default Mycontext