import React, { useEffect, useState,useContext } from 'react'
import Mycontext from './Mycontext.jsx';
import { toastError, toastSuccess } from "./Utils.jsx"
import { ToastContainer } from "react-toastify"
import { useNavigate, useLocation, redirect } from "react-router-dom"
import OTPInput from "otp-input-react"

const Verification = () => {
  const [otp, updateOtp] = useState("")
  const navigate = useNavigate()
  const location = useLocation()
  const {user,setUser,red,setRed} =useContext(Mycontext)

  useEffect(() => {
    if (location.state?.toastMessage) {
      console.log(location.state.toastMessage)
      toastSuccess(location.state.toastMessage)
    }
  }, [location])

  const otpSend = async (e) => {
    e.preventDefault()

    const res = await fetch("http://localhost:5000/emailVerification", {
      method: "POST",
      body: JSON.stringify({ otp }),
      credentials: "include",
      headers: { "Content-Type": "application/json" },
    })

    const data = await res.json()
    const route=localStorage.getItem("route")
    console.log(route,"xyz")
    if (!data.success) {
      toastError(data.message)
    } 
    
    else if(route){
      setRed(true)
      navigate(route,{state:{toastMessage:data.message}})
    }
    else{
      setRed(true)
      navigate("/",{state:{toastMessage:data.message}})
    }
  }

  const resend = async () => {
    const res = await fetch("http://localhost:5000/resendOtp", {
      credentials: "include",
    })

    const data = await res.json()

    if (!data.success) {
      toastError(data.message)
    } else {
      toastSuccess(data.message)
    }
  }

  const clear = () => {
    updateOtp("")
  }

  return (
    <div className='verification'>
      <form onSubmit={otpSend}>
        <h2>Verify OTP</h2>
        <p>OTP is sent to your Mobile Email Id</p>
        <p>{location.state?.email || "amaan@gmail.com"}</p>

        <OTPInput
          className="otpcolumn"
          value={otp}
          onChange={updateOtp}
          autoFocus
          OTPLength={6}
          otpType="number"
          disabled={false}
        />

        <div className='otpbtn'>
          <button type="submit">Verify</button>
          <button type="button" onClick={clear}>Clear</button>
        </div>

        <h3 className='otpTime'>0:38</h3>

        <p>
          Didn’t receive OTP?{" "}
          <button type="button" onClick={resend} className='otpResBtn'>
            Request again
          </button>
        </p>
      </form>
      <ToastContainer />
    </div>
  )
}

export default Verification
