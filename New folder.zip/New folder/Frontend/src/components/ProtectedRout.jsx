import React, { useState } from 'react'
import { useEffect,useContext } from 'react';
import Mycontext from '../Mycontext.jsx';
import {Navigate, useNavigate,useLocation} from "react-router-dom"
import { toastError, toastSuccess } from '../Utils.jsx';


const ProtectedRout = ({Page}) => {  
  const redirect=useNavigate()  
  const location=useLocation()
  const {user,setUser,red,setRed} =useContext(Mycontext)
  const route=localStorage.getItem("route")
  console.log(route)
  console.log(user.success)
  useEffect(()=>{
    if(route && red){
      setRed(false)
      console.log("now")
      redirect(route)
      setTimeout(()=>{
        localStorage.removeItem("route")
      },100)
    }
  },[location])
  if(user.success==undefined){
    return <Navigate to="/login"/>
  }

  return (
    user.success?<Page/>:<Navigate to="/login"/>
  )
}

export default ProtectedRout