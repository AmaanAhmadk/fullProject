import './Product.css';
import products from "./Data.js"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronLeft,faChevronRight } from '@fortawesome/free-solid-svg-icons';
import {useState} from "react"
function Product() {
  const [pageNo,setPageNo]=useState(1)
  const productPerPage=12
  const page=Math.ceil(products.length/productPerPage)
  const firstPaginationValue=(pageNo*productPerPage-productPerPage)
  const LastPaginationValue=(pageNo*productPerPage)
  
  return (
    <>
    <div className="main-container">
      <div className="sidebar">
        <h4>Brand</h4>
        <p>
          <input type="checkbox" /> Zara
        </p>
        <p>
          <input type="checkbox" /> H&M
        </p>
        <p>
          <input type="checkbox" /> Nike
        </p>
        <p>
          <input type="checkbox" /> Adidas
        </p>
        <p>
          <input type="checkbox" /> Levi`s
        </p>
        <p>
          <input type="checkbox" /> Gucci
        </p>

        <h4>Price</h4>
        <p>
          <input type="checkbox" /> Under ₹3000
        </p>
        <p>
          <input type="checkbox" /> ₹1000 to ₹1500
        </p>
        <p>
          <input type="checkbox" /> ₹1500 to ₹2000
        </p>
        <p>
          <input type="checkbox" /> ₹2000 to ₹2500
        </p>
        <p>
          <input type="checkbox" /> ₹2500 to ₹3000
        </p>
        <p>
          <input type="checkbox" /> ₹3000 to ₹3500
        </p>

        <h4>Color</h4>
        <p>
          <input type="checkbox" /> Black
        </p>
        <p>
          <input type="checkbox" /> Red
        </p>
        <p>
          <input type="checkbox" /> Blue
        </p>
        <p>
          <input type="checkbox" /> Green
        </p>
        <p>
          <input type="checkbox" /> White
        </p>
        <p>
          <input type="checkbox" /> Yellow
        </p>
      </div>

      <div className="products-grid">
        {products.map((product,i) => (
          <div className="product-card" key={i}>
            <div className="product-image">
              <img src={product.image} alt={product.name} />
            </div>
            <h3 className="product-name">{product.name}</h3>
            <p className="product-detail">{product.detail}</p>
            <div className="product-actions">
              <button className="add-to-cart">Add to Cart</button>
            </div>
          </div>
        ))}
      </div>
    </div>
    <div className='paginationContainer'>
      <button disabled={pageNo==1} onClick={()=>setPageNo(pageNo-1)}><FontAwesomeIcon icon={faChevronLeft} className='chevron'/></button>
        {
          Array.from({length:page},(_,i)=>{
            return <h3 onClick={()=>setPageNo(i+1)} key={i} style={{background:pageNo==i+1&&"black",color:pageNo==i+1&&"white",cursor:"pointer",display:i+1>5&&"none"}}>{i+1}</h3>
          })
        }
      <button disabled={pageNo==page} onClick={()=>setPageNo(pageNo+1)}><FontAwesomeIcon icon={faChevronRight} className='chevron'/></button>  
    </div>
    </>
  );
}

export default Product;
