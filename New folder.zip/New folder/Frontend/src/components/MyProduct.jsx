import React from 'react'

const Update = () => {
  return (
    <div className='signup'>
    <form method='post'>
      <h2>MyProduct</h2>
      <input placeholder='Enter Name' name='name'/>
      <input placeholder='Enter Email' name='email'/>
      <input placeholder='Enter Password' name='password'/><br/>
      <button>Submit</button>
    </form>
    </div>
  )
}

export default Update