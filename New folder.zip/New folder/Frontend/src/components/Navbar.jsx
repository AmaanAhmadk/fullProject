import "./Navbar.css"
import { NavLink,useLocation } from 'react-router-dom';
import { useState,useContext } from 'react';
import Mycontext from '../Mycontext.jsx';
import Logout from "./Logout.jsx";
import { toastError, toastSuccess } from "../Utils.jsx";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBagShopping,faXmark } from '@fortawesome/free-solid-svg-icons';



const Navbar = () => {
  const [open, setOpen] = useState(false)
  const {user,setUser} =useContext(Mycontext)
  const location=useLocation()
  const toggle = () => {
    setOpen(!open)
    }

  const notLoginMsg=(route)=>{
      if(!user.success && route){
        localStorage.setItem("route",route)
        setTimeout(() => {
      toastError("you are not logged in")
      
    },100);
    
  }
  else{
    localStorage.setItem("route","/")
  }
    
  }

    return (
      <div className='navbar'>
        <div className='nav1'>
          <span className="logo"><FontAwesomeIcon icon={faBagShopping} style={{marginRight:"10px",color:"#d4af37"}}/>Amacloth</span>
          <div className='nav2'>
            <div className={`navlinks ${open?'show':""}`}>
              <NavLink onClick={()=>{setOpen(false)}} to="/"><h4 className={"/"==location.pathname?"actives":""}>Home</h4></NavLink>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg("/addProduct")}} to={"/addProduct"}><h4 className={"/addProduct"==location.pathname?"actives":""}>AddProduct</h4></NavLink>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg("/myProduct")}} to={"/myProduct"}><h4 className={"/myProduct"==location.pathname?"actives":""}>Myproduct</h4></NavLink>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg("/about")}} to={"/about"}><h4 className={"/about"==location.pathname?"actives":""}>Aboutus</h4></NavLink>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg("/orders")}} to="/orders"><h4 className={"/orders"==location.pathname?"actives":""}>Orders</h4></NavLink>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg("/cart")}} to={"/cart"}><h4 className={"/cart"==location.pathname?"actives":""}>Cart</h4></NavLink>
              {user.success?
              <Logout value={setOpen}/>:
              <>
              <NavLink onClick={()=>{setOpen(false);notLoginMsg()}} to="/signup"><h4 className={"/signup"==location.pathname?"actives":""}>Signup</h4></NavLink>
              </>
              }
            </div>
            <span className='menu' onClick={toggle} style={{display:open&&"none"}}> &#9776;</span>
            <FontAwesomeIcon icon={faXmark} style={{display:!open&&"none"}} onClick={toggle} className="cross"/>
          </div>
      </div>
      </div>

    )
  }

export default Navbar