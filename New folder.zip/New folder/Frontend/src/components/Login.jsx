import React, { useEffect, useState,useContext } from 'react'
import { Link } from "react-router-dom"
import { toast, ToastContainer } from "react-toastify"
import { toastError, toastSuccess } from "../Utils.jsx"
import { useNavigate,useLocation } from "react-router-dom"
import "../App.css"
import githubImg from "../icons/github-img.png"
import googleImg from "../icons/google-img.webp"
import Mycontext from '../Mycontext.jsx';
import { githubProvider, googleProvider, auth } from "../Firebase.jsx"
import { signInWithPopup } from 'firebase/auth'


const Login = () => {
  const {red,setRed,user,setUser} =useContext(Mycontext)
  const redirect = useNavigate()
  const location=useLocation()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const signupPost = async (e) => {
try{
      e.preventDefault()
    const data = await fetch("http://localhost:5000/login/post", {
      method: "post",
      body: JSON.stringify({ email, password}),
      credentials: 'include',
      headers: { "content-type": "application/json" }
    }).then((x) => {
      return x.json()
    })

    if (!data.success) {
      toastError(data.message)
    }
    else {
      redirect('/verification',{state:{toastMessage:data.message}})
    }
}
catch{
  toastError("server error")
}

  }

const clickAuth = async (providerType) => {
    try {
      const provider = providerType === "github" ? githubProvider : googleProvider;
      const response = await signInWithPopup(auth, provider);
      const { email, emailVerified } = response.user;

      if (!emailVerified) {
        toastError(`${providerType} email is not verified`);
      } else {
        // console.log(email);
        const result=await fetch("http://localhost:5000/clickAuthLogin",{
          method:"post",
          body:JSON.stringify({email,emailVerified,providerType}),
          headers:{"content-type":"application/json"},
          credentials:"include"
        }).then((v)=>v.json())
        
        if(!result.success){
          toastError(result.message)
        }
        else{
          setRed(true)
          redirect('/', { state: { toastMessage: result.message } })
        }
      }
    } catch (error) {
      toastError("OAuth login failed");
      console.log(error);
    }
  }

  return (
    <div className='authUi'>
      <form onSubmit={signupPost} className='authLog'>
        <h2>Login</h2>
        <input placeholder='Enter Email' name='email' onChange={(e) => { setEmail(e.target.value) }} />
        <input placeholder='Enter Password' name='password' onChange={(e) => { setPassword(e.target.value) }} />
        <Link to="/">Forgot Password?</Link>
        <button>Submit</button>
        <p>Don't have an account? <Link to="/signup">Sign up</Link></p>

        <div>
          <p onClick={() => clickAuth("github")}><img src={githubImg} height="20px" /> Login with Github</p>
        </div>
        <div>
          <p onClick={() => clickAuth("google")}><img src={googleImg} height="30px" />Login with Google</p>
        </div>
      </form>
      <ToastContainer />
    </div>
  )
}


export default Login