import React from 'react'

const Cart = () => {
  return (
    <div className='signup'>
    <form method='post'>
      <h2>Cart</h2>
      <input placeholder='Enter Name' name='name'/>
      <input placeholder='Enter Email' name='email'/>
      <input placeholder='Enter Password' name='password'/><br/>
      <button>Submit</button>
    </form>
    </div>
  )
}

export default Cart