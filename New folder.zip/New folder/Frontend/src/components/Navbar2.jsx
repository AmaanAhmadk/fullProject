import React, { useEffect, useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import "./Navbar2.css"

const Navbar2 = () => {
  const [placeholder, setPlaceholder] = useState('');
  const [categories, setCategories] = useState([""]);

  const updatePlaceholder = () => {
    if (window.innerWidth < 612) {
      setPlaceholder("Search for products...");
    } else {
      setPlaceholder("Search for products, brands and more...");
    }
  };

window.addEventListener("click",(e)=>{
    setBorder(false)
})

  useEffect(() => {
    updatePlaceholder(); // Set initial placeholder
    window.addEventListener('resize', updatePlaceholder); // Add listener

    return () => {
      window.removeEventListener('resize', updatePlaceholder); // Clean up
    };
  }, []);

  return (
    <>
    <div className='navbar2Container'>
      <div className='searchContainer' style={{border:"3px solid #d4af37",borderRadius:"13px"}}>
        <input placeholder={placeholder} />
        <button><FontAwesomeIcon icon={faMagnifyingGlass} /> Search</button>
      </div>
    </div>
    <div className="categoriesContainer">
      <h3>All</h3>
      <h3>Men</h3>
      <h3>Women</h3>
      <h3>Kids</h3>
      <h3>Accessories</h3>
      <h3>Beauty</h3>
    </div>
    </>
  );
}

export default Navbar2;
