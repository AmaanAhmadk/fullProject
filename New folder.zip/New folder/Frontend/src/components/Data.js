
  const products = [
    {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },

        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
        {
      id: 1,
      name: "Men's Cotton Shirt",
      brand: "Levi's",
      category: 'Shirt',
      price: 29.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVuJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Lightweight cotton shirt perfect for everyday wear with a breathable fabric.',
    },
    {
      id: 2,
      name: "Women's Skinny Jeans",
      brand: 'Zara',
      category: 'Jeans',
      price: 49.99,
      size: ['XS', 'S', 'M', 'L'],
      image:
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8amVhbnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Stylish and snug skinny jeans with a flattering fit and stretchable denim.',
    },
    {
      id: 3,
      name: 'Unisex Pocket Hoodie',
      brand: 'H&M',
      category: 'Hoodie',
      price: 39.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvb2RpZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Cozy unisex hoodie made with brushed fleece and kangaroo front pocket.',
    },
    {
      id: 5,
      name: "Men's Slim Trousers",
      brand: 'Uniqlo',
      category: 'Trousers',
      price: 44.0,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJvdXNlcnN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
      detail:
        'Modern slim-fit trousers ideal for office or casual settings with stretch comfort.',
    },
    {
      id: 6,
      name: "Women's Elegant Blouse",
      brand: 'Zara',
      category: 'Top',
      price: 24.99,
      size: ['XS', 'S', 'M'],
      image:
        'https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHdvbWVuJTIwdG9wfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Elegant blouse with flowy fabric and a tailored fit, perfect for both work and outings.',
    },
    {
      id: 7,
      name: "Men's Winter Jacket",
      brand: 'The North Face',
      category: 'Jacket',
      price: 129.99,
      size: ['M', 'L', 'XL', 'XXL'],
      image:
        'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
      detail:
        'Insulated winter jacket with water-resistant shell and thermal lining for extreme cold.',
    },
    {
      id: 8,
      name: "Men's Graphic T-Shirt",
      brand: 'Nike',
      category: 'T-Shirt',
      price: 19.99,
      size: ['S', 'M', 'L', 'XL'],
      image:
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=60',
      detail:
        'Soft cotton t-shirt with premium finish for ultimate comfort and bold graphic print.',
    },
  ];

  export default products