import React, { useState,useEffect } from 'react'
import {toast,ToastContainer} from "react-toastify"
import {toastError,toastSuccess} from "../Utils.jsx"
import "./AddProduct.css"
import { useLocation } from 'react-router-dom'

const AddProduct = () => {
const [file,setFile]=useState()
const [productData,setProductData]=useState({productName:"",description:"",category:"",
  subCategory:"",price:"",color:""})
const allSizes=["M","L","XL","XLL"]  
const [sizes,setSizes]=useState({})

const handleSizes=(val,size)=>{
  if(val){
    setSizes({...sizes,[size]:val})
  }
  else{
    const updateSize=({...sizes})
    delete updateSize[size]
    setSizes(updateSize)
  }
}

  const sendFile=async(e)=>{
    e.preventDefault()
  const {productName,description,category,subCategory,price,color}=productData  
  const formData = new FormData()
  formData.append("img", file)
  formData.append("productName",productName )
  formData.append("description",description)
  formData.append("category",category)
  formData.append("subCategory",subCategory)
  formData.append("price",price)
  formData.append("color",color)
  formData.append("sizes",JSON.stringify(sizes));

  const data = await fetch("http://localhost:5000/product/post", {
      method: "POST",
      body: formData
    }).then((x)=>x.json())
  }

  const location = useLocation();

  // useEffect(() => {
  //   if (location.state?.toastMessage) {
  //     toastSuccess(location.state.toastMessage);
  //     redirect(location.pathname, {state:{}})
  //   }
  // }, [location]);

  return (
    <div>
    <form onSubmit={sendFile}>
      <h2>file</h2>
      <input name="productName" placeholder="productName" onChange={(e)=>setProductData({...productData,productName:e.target.value})}/>
      <input name="description" placeholder="description" onChange={(e)=>setProductData({...productData,description:e.target.value})}/>
      <input name="category" placeholder="category" onChange={(e)=>setProductData({...productData,category:e.target.value})}/>
      <input name="subCategory" placeholder="subCategory" onChange={(e)=>setProductData({...productData,subCategory:e.target.value})}/>
      <input name="price" placeholder="price" onChange={(e)=>setProductData({...productData,price:e.target.value})}/>
      <input name="color" placeholder="color" onChange={(e)=>setProductData({...productData,color:e.target.value})}/>
      <input type="file" name='img' onChange={(e)=>setFile(e.target.files[0])}/>
      <button>Submit</button>
      {
        allSizes.map((size)=>{
          return(
            <div key={size}>
            <span className="sBoxLayot">{size}: </span>
            <input onChange={(e)=>handleSizes(e.target.value,size)} placeholder={`Enter Qty of ${size}`}/>
            </div>
          )
        })
      }
    </form>
    </div>
  )
}

export default AddProduct