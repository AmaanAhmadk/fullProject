import {NavLink} from "react-router-dom"
import Mycontext from "../Mycontext.jsx"
import {useContext} from "react"
import { toastError, toastSuccess } from "../Utils.jsx"



const Logout = ({setOpen}) => {
const {fetchUser} =useContext(Mycontext)  
const logout=async()=>{
    try{
      await fetch("http://localhost:5000/logout",{
        credentials:"include"
    })
    fetchUser()
    toastSuccess("logout successfully")
    }
    catch{
      console.log("server error")
    }
}     
  return (
    <h4 onClick={()=>{logout();setOpen(false)}} className="logout">Logout</h4>
  )
}

export default Logout