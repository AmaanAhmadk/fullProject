import {  useEffect, useState } from "react";
import Mycontext from "./Mycontext.jsx";
import { useLocation } from "react-router-dom";
import { toastError } from "./Utils.jsx";


const ContextProvider=({children})=>{
  const location=useLocation()
  const [product,setProduct] =useState([])
  const [user,setUser]=useState({})
  const [red,setRed]=useState(false)
    const fetchProduct=async()=>{
    try{
      const data=await fetch("http://localhost:5000/product",{
      credentials:"include"
    })
    .then((res)=>res.json())
    setProduct(data)
    }
    catch(err){
      console.log("server error")
    }
    }

    const fetchUser=async()=>{
    try{
    const data=await fetch("http://localhost:5000/isAuth",{
    credentials:"include"  
    })
    .then((res)=>res.json())
      setUser(data)
    }
    catch{
      console.log("server error")
    }
    }

  useEffect(()=>{
    fetchProduct()
    fetchUser()
    },[location.pathname])
    return(
        <Mycontext.Provider value={{product,setProduct,user,setUser,fetchUser,red,setRed}}>
          {children}
        </Mycontext.Provider>
    )
}

export default ContextProvider