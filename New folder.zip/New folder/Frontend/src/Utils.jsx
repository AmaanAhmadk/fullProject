import {toast} from "react-toastify"

const toastError=(msg)=>{
   toast.error(msg,{position:"top-right"})
}

const toastSuccess=(msg)=>{
    toast.success(msg,{position:"top-right"})
}

export {toastError,toastSuccess}