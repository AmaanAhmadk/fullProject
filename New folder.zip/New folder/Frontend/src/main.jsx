import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Signup from './components/Signup.jsx'
import Login from './components/Login.jsx'
import AddProduct from './components/AddProduct.jsx'
import MyProduct from './components/MyProduct.jsx'
import About from './components/About.jsx'
import Verification from './Verification.jsx'
import ContextProvider from './ContextProvider.jsx'
import Product from './components/Product.jsx'
import Navbar from './components/Navbar.jsx'
import Footer from './components/Footer.jsx'
import Cart from './components/Cart.jsx'
import ProtectedRout from './components/ProtectedRout.jsx'
import SignupLoginProtect from './components/SignupLoginProtect.jsx'
import Orders from "./components/Ordes.jsx"


createRoot(document.getElementById('root')).render(
  // <StrictMode>
    <BrowserRouter>
      <ContextProvider>
        <Navbar/>
        <Routes>
          <Route path='*' element={<App />} />
          <Route path='/' element={<App />} />
          <Route path='/signup' element={<SignupLoginProtect Page={Signup}/>}/>
          <Route path='/login' element={<SignupLoginProtect Page={Login}/>} />
          <Route path='/orders' element={<ProtectedRout Page={Orders}/>} />
          <Route path='/addProduct' element={<ProtectedRout Page={AddProduct}/>} />
          <Route path='/myProduct' element={<ProtectedRout Page={MyProduct} />} />
          <Route path='/about' element={<ProtectedRout Page={About}/>} />
          <Route path='/cart' element={<ProtectedRout Page={Cart}/>} />
          <Route path='/verification' element={<Verification />} />
          <Route path='/product' element={<Product />} />
        </Routes>
        <Footer/>
      </ContextProvider>
    </BrowserRouter>
  // {/* </StrictMode> */}
)
