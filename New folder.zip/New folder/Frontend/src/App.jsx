import Product from "./components/Product.jsx"
import {useEffect} from "react"
import {toastSuccess} from "./Utils.jsx"
import { useNavigate, useLocation } from 'react-router-dom';
import { ToastContainer } from "react-toastify"
import Navbar2 from "./components/Navbar2.jsx";
import HeroSection from "./components/HeroSection.jsx"


function App() {
  const redirect=useNavigate()
  const location = useLocation();

  useEffect(() => {
    console.log("yes")
    if (location.state?.toastMessage) {
      toastSuccess(location.state.toastMessage);
      redirect(location.pathname, {state:{}})
    }
  }, [location]);
  return (
    <>
    <Navbar2/>
    <HeroSection/>
    <Product/>
    <ToastContainer/>
    </>
  )
}

export default App
