const mongoose=require("mongoose")

const dbConnection=async()=>{
    try{
await mongoose.connect("mongodb://localhost:27017/newDB")
console.log("DB Connected")
    }
    catch(err){
        console.log("DB Connection failed")
    }
}
module.exports=dbConnection()