const express = require("express")
const router=express.Router()
const {registerPost,loginPost,logout,emailVerification,productPost,product,resendOtp,isAuth,clickAuthRegister,clickAuthLogin}=require("../controller/userController.js")
const {userVerified,isLogin,productVal}=require("../middlewares/cheack.js")




router.get("/logout",logout)

router.get("/product",product)

router.post("/product/post",productPost)

router.post("/register/post",userVerified,registerPost)

router.post("/login/post",loginPost)

router.post("/emailVerification", emailVerification)

router.get("/resendOtp",resendOtp)

router.get("/isAuth",isAuth)

router.post("/clickAuthRegister",clickAuthRegister)

router.post("/clickAuthLogin",clickAuthLogin)

module.exports=router