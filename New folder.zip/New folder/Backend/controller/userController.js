const {registerVal,loginVal} = require("../validation/userVal.js")
const userModel = require("../models/userModel.js")
const productModel=require("../models/productModel.js")
const bcrypt = require("bcrypt")
const {sendEmail,otpGenrate} = require("../utils.js")
const jwt=require("jsonwebtoken")
const multer=require("multer")
const fs=require("fs")


const registerPost = async (req, res) => {
    try{
    const { name, email, password } = req.body
    const result = registerVal.safeParse({ name, email, password })
    const emailAlready = await userModel.findOne({ email })
    if (!(name && email && password)) {
        return res.status(400).json({success:false,message:"All field is required"})
    }
    else if (emailAlready?.isVerified) {
        return res.status(400).json({success:false,message:"This email is already exist"})
    }
    else if (!result.success) {
        return res.status(400).json({success:false,message:result.error.issues[0].message})
    }
    else if(emailAlready?.clickAuth){
        const {name,email,password}=result.data
        const salt=await bcrypt.genSalt(10)
        const hash=await bcrypt.hash(password,salt)
        const otp =otpGenrate() 
        const userData = await userModel.updateOne({email},{ name, email, password: hash, otp,otpExpire:Date.now()+10*60*1000 })
        const message = `<h1>Your OTP is ${otp}</h1><p>This code is valid for 10 minutes.</p>`;
        sendEmail(email,message)
        res.cookie("email", email, {maxAge: 10 * 60 * 1000});
        return res.status(200).json({success:true,message:"please verify your email"})
    }
    else {
        const {name,email,password}=result.data
        const salt=await bcrypt.genSalt(10)
        const hash=await bcrypt.hash(password,salt)
        const otp =otpGenrate() 
        const userData = await userModel.create({ name, email, password: hash, otp,otpExpire:Date.now()+10*60*1000 })
        const message = `<h1>Your OTP is ${otp}</h1><p>This code is valid for 10 minutes.</p>`;
        sendEmail(email,message)
        res.cookie("email", email, {maxAge: 10 * 60 * 1000});
        return res.status(200).json({success:true,message:"please verify your email"})
         }
    }
    catch(err){
        console.log(err)
        return res.status(500).json({success:false,message:"server error"})
    }

}


const loginPost=async(req,res)=>{
    try{
    const { email, password } = req.body
    const result=loginVal.safeParse({email,password})
    if(!email || !password){
        return res.status(400).json({success:false,message:"All field is required"})
    }
    else if(!result.success){
        return res.status(400).json({success:false,message:result.error.issues[0].message})
    }
    else{
        const data=await userModel.findOne({email:email})
        if(!data){
            return res.status(400).json({success:false,message:"User not found"})
        }
        else if(!data.isVerified){
            return res.status(400).json({success:false,message:"Email not verified"})
        }
        const passMatch = await bcrypt.compare(password, data.password)
        if(!passMatch){
            return res.status(400).json({ success: false, message: "Invalid email or password" });

        }
        else{
            const otp=otpGenrate()
            await userModel.findOneAndUpdate({email:email},{otp:otp,otpExpire:Date.now()+10*60*1000})
            const message = `<h1>Your OTP is ${otp}</h1><p>This code is valid for 10 minutes.</p>`;
            sendEmail(email,message)
            res.cookie("email",email,{maxAge:10*60*1000})
            return res.status(200).json({success:true,message:"Please check your email"})
        }
    }
    }
    catch(err){
        return res.status(500).json({success:false,message:"server error"})
    }
}

const emailVerification = async(req, res) => {
    try{
    const email=req.cookies.email
    console.log(email)
    const data=await userModel.findOne({email:email})
    const inputOtp=req.body.otp
    if(!email){
        return res.status(400).json({success:false,message:"please signup or login "})
    }
    else if(!data){
        return res.status(400).json({success:false,message:"please register first"})
    }
    else if(!inputOtp){
        return res.status(400).json({success:false,message:"Enter otp first"})
    }
    else if(data.otpExpire<Date.now()){
        return res.status(400).json({success:false,message:"your otp is expire"})
    }
    else if(inputOtp==data.otp){
        const token=jwt.sign({email},process.env.SECRET_KEY,{expiresIn:"24h"})
        res.clearCookie("email")
        res.cookie("token",token)
        if(data.isVerified){
            await userModel.findOneAndUpdate({email:email},{otpExpire:null,otp:null})
            return res.status(200).json({success:true,message:"login succesfully"})
        }
        else{
            await userModel.findOneAndUpdate({email:email},{ isVerified: true, otpExpire: null, otp: null })
            return res.status(200).json({success:true,message:"Registered successfully"})
        }
        
    }
    else{
        return res.status(400).json({ success: false, message: "Wrong OTP" });

    }
}
catch(err){
    return res.status(500).json({success:false,message:"server error"})
}
}

const resendOtp = async(req, res) => {
    try{
    const email=req.cookies.email
    if(!email){
        return res.status(400).json({success:false,message:"please signup or login"})
    }
    const data=await userModel.findOne({email:email})
    if(!data){
        return res.status(400).json({success:false,message:"please login"})
    }
    else{
        
        const otp=otpGenrate()
        const message = `<h1>Your OTP is ${otp}</h1><p>This code is valid for 10 minutes.</p>`;

        await userModel.findOneAndUpdate({email:email},{otp:otp,otpExpire:Date.now()+10*60*1000})
        sendEmail(email,message)
        return res.status(200).json({success:true,message:"otp send successfully"})
    }
    }
    catch(err){
        return res.status(500).json({success:false,message:"server error"})
    }
    
}

const logout=(req,res)=>{
    try{
    res.clearCookie("token")
    return res.status(200).json({success:true,message:"logout successfully"})
    }
    catch(err){
        return res.status(500).json({success:false,message:"server error"})
    }
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'productImg')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  }
})

const imgFilter=(req,file,cb)=>{
    const allowedTypes = ["image/jpg","image/jpeg", "image/png"];
    if(allowedTypes.includes(file.mimetype)){
        cb(null,true)
    }
    else{
        cb(new Error("only jpg or png file allow"),false)
    }
}

const upload = multer({ storage: storage,fileFilter:imgFilter }).single("img")

const productPost=(req,res)=>{

upload(req,res,async(err)=>{
try{    
const {productName,description,category,subCategory,price,sizes,color}=req.body
const parsSizes=JSON.parse(sizes)
const arr=Object.values(parsSizes).filter((v)=>v!="")
console.log(arr.length)
    if(err){
        return res.status(400).json({success:false,message:err.message})
    }
    else if(!req.file){
        return res.status(400).json({success:false,message:"All field is required"})
    }
    else if(!productName || !description || !category || !subCategory || !price || !color || arr.length==0){
    fs.unlinkSync(req.file.path)
    return res.status(400).json({success:false,message:"All field is required"})
    }
    else{
        await productModel.create({productName,description,color,category,subCategory,price,sizes,img:req.file.path})
        return res.status(200).json({success:true,message:"image save successfully"})
    }
}
catch(err){
     console.log(err.message)
     return res.status(500).json({success:false,message:"server error"})
}
})

}

const product=async(req,res)=>{
    const data=await productModel.find({})
    res.send(data)
}

const isAuth=async(req,res)=>{
        try{
            const token=req?.cookies?.token
            if(!token){
                return res.status(401).json({success:false,message:"you are not authenticated"}) 
            }
            const decoded=jwt.verify(req?.cookies?.token,process.env.SECRET_KEY)
            if(!decoded?.email){
                return res.status(401).json({success:false,message:"you are not authenticated"}) 
            }
            const data=await userModel.findOne({email:decoded?.email})
            if(!data?.isVerified && !data?.clickAuth){
                return res.status(401).json({success:false,message:"you are not registered"})
            }
            
            else{
                return res.status(200).json({success:true,message:"you are login",data:data})
            }
        }
        catch(err){
            console.log(err.message)
            return res.status(500).json({success:false,message:"server error"})
        }
}

const clickAuthRegister=async(req,res)=>{
    try{
        const {email,emailVerified}=req.body
        if(!email || !emailVerified){
            return res.status(400).json({success:false,message:"email not verified"})
        }
        const user=await userModel.findOne({email})
        if(user?.clickAuth){
            return res.status(400).json({success:false,message:"This email is already exist"})
        }
        else if(user){
            const data=await userModel.updateOne({email},{clickAuth:emailVerified})
            const token=jwt.sign({email},process.env.SECRET_KEY,{expiresIn:"24h"})
            res.cookie("token",token)
             return res.status(200).json({success:true,message:"register successfully"})
        }
        else{
            const data=await userModel.create({email,clickAuth:emailVerified})
            const token=jwt.sign({email},process.env.SECRET_KEY,{expiresIn:"24h"})
            res.cookie("token",token)
             return res.status(200).json({success:true,message:"register successfully"})
        }
    }
    catch(err){
        console.log(err.message)
        return res.status(500).json({success:false,message:"server error"})
    }
}

const clickAuthLogin=async(req,res)=>{
    try{
        const {email,emailVerified,providerType}=req.body
        if(!email || !emailVerified){
            return res.status(400).json({success:false,message:`${providerType} email not verified`})
        }
        const user=await userModel.findOne({email})
        if(user?.email!==email || !user?.clickAuth){
            return res.status(400).json({success:false,message:"You are not registered"})
        }
        else{
            const token=jwt.sign({email},process.env.SECRET_KEY,{expiresIn:"24h"})
            res.cookie("token",token)
             return res.status(200).json({success:true,message:"login successfully"})
        }
    }
    catch(err){
        console.log(err.message)
        return res.status(500).json({success:false,message:"server error"})
    }
}

module.exports = { registerPost,loginPost,emailVerification,logout,productPost,resendOtp,product,isAuth,clickAuthRegister,clickAuthLogin }