const mongoose = require("mongoose")

const productSchema = new mongoose.Schema({
    productName: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        trim: true,
    },
    img: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true,
        trim: true,
    },
    subCategory: {
        type: String,
        required: true,
        trim: true,
    },

    price: {
        type: String,
        required: true,
        trim:true
    },
    sizes: {
        type:{},
        required: true,
    },
    color:{
        type:String,
        required:true
    },
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user"
    }


},{timestamps:true})

module.exports = mongoose.model("product", productSchema)